import { NextResponse } from 'next/server';
import { isPasswordConfigured, sessionFromRequest } from './auth';

/** API Route 共享守卫：未配置密码返回 503，未登录返回 401。兼容 Cookie 与 Authorization: Bearer */
export function guardRequest(req: Request): NextResponse | null {
  if (!isPasswordConfigured()) {
    return NextResponse.json(
      { error: '服务器未设置 PASSWORD 环境变量' },
      { status: 503 }
    );
  }
  if (!sessionFromRequest(req)) {
    return NextResponse.json({ error: '未登录' }, { status: 401 });
  }
  return null;
}

export function jsonError(message: string, status: number): NextResponse {
  return NextResponse.json({ error: message }, { status });
}
